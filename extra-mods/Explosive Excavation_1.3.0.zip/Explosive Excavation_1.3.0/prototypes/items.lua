local item_sounds = require("__base__.prototypes.item_sounds")

data:extend({
  {
    type = "item",
    name = "blasting-charge",
    icon = "__Explosive Excavation__/graphics/icons/blasting-explosives.png",
    icon_size = 32,
    subgroup = "terrain",
    order = "c[landfill]-b[blasting-charge]",
    inventory_move_sound = item_sounds.explosive_inventory_move,
    pick_sound = item_sounds.explosive_inventory_pickup,
    drop_sound = item_sounds.explosive_inventory_move,
    stack_size = 20,
    place_as_tile =
    {
      result = "water",
      condition_size = 1,
      condition = {layers={water_tile=true}}
    }
  }
})