local space_age_tiles =
{
  ["nauvis"] = nil,
  ["vulcanus"] = "lava",
  ["fulgora"] = "oil-ocean-deep",
  ["gleba"] = "gleba-deep-lake",
  ["aquilo"] = "brash-ice",
}

function placedTiles(entity, tiles)
  local surface = entity.surface
  local replacement_tile = space_age_tiles[surface.name]
  for i, tile in pairs(tiles) do
    surface.create_entity({name = "big-explosion", force = entity.force, position = {tile.position.x+0.5, tile.position.y+0.5}})
    tile.name = replacement_tile
  end
  if replacement_tile then
    surface.set_tiles(tiles)
  end
end

script.on_event(defines.events.on_player_built_tile, function(event)
  if event.item and event.item.valid and event.item.name == "blasting-charge" then
    placedTiles(game.players[event.player_index], event.tiles)
  end
end)

script.on_event(defines.events.on_robot_built_tile, function(event)
  if event.item and event.item.valid and event.item.name == "blasting-charge" then
    placedTiles(event.robot, event.tiles)
  end
end)